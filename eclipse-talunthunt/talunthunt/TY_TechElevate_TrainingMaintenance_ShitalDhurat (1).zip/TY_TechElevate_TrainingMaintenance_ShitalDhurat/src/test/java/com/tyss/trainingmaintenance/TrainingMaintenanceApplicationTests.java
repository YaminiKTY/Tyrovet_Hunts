package com.tyss.trainingmaintenance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingMaintenanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
