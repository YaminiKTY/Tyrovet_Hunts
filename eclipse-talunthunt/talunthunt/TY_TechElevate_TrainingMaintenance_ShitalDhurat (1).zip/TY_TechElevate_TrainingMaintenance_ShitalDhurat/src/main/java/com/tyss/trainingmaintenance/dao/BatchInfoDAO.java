package com.tyss.trainingmaintenance.dao;

import com.tyss.trainingmaintenance.dto.BatchInfo;

public interface BatchInfoDAO {

	public BatchInfo addBatch(BatchInfo batch);
}
