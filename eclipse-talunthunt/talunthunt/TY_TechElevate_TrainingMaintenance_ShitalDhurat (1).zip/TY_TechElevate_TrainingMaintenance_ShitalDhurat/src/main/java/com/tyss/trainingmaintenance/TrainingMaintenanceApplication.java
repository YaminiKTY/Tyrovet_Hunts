package com.tyss.trainingmaintenance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingMaintenanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingMaintenanceApplication.class, args);
	}

}
