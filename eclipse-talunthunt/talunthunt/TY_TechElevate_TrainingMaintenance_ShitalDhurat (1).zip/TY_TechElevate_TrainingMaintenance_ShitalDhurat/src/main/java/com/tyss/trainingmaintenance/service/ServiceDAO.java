package com.tyss.trainingmaintenance.service;

import com.tyss.trainingmaintenance.dto.BatchInfo;

public interface ServiceDAO {
	public BatchInfo addBatch(BatchInfo batch);
}
